import pandas as pd 

r_filenameCSV = 'C:/Users/Sanjogita/Desktop/Data Exploration/realestatetransactions.csv'
w_filenameTSV = 'C:/Users/Sanjogita/Desktop/Data Exploration/realestatetransactions.tsv'

csv_read = pd.read_csv(r_filenameCSV)


df=csv_read.fillna(method='ffill',axis="1");