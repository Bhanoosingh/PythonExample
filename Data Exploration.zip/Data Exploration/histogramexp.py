import pandas as pd 
import matplotlib.pyplot as plt

r_filenameCSV = 'C:/Users/Sanjogita/Desktop/Data Exploration/realestatetransactions.csv'
w_filenameTSV = 'C:/Users/Sanjogita/Desktop/Data Exploration/realestatetransactions.tsv'

csv_read = pd.read_csv(r_filenameCSV)


df=csv_read.fillna(method='ffill');
csv_read = df.query('beds < 5')

# generate histogram by number of beds
csv_read.hist(
    column='price', 
    by='beds', 
    xlabelsize=8, 
    ylabelsize=8, 
    sharex=False, 
    sharey=False,
    figsize=(9,7),
    bins=8
)

plt.savefig(
    'C:/Users/Sanjogita/Desktop/Data Exploration/histogram.pdf'
)

# show the figures
plt.show()